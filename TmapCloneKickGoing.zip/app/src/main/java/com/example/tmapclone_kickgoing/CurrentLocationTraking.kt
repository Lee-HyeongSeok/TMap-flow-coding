package com.example.tmapclone_kickgoing

import android.location.Location
import android.location.LocationListener
import android.os.Bundle
import com.skt.Tmap.TMapGpsManager

class CurrentLocationTraking(): TMapGpsManager.onLocationChangedCallback{
    override fun onLocationChange(p0: Location?) {

    }
}